
-   kriskowal Kris Kowal Copyright (C) 2009-2011 MIT License
-   tlrobinson Tom Robinson Copyright (C) 2009-2010 MIT License (Narwhal
    Project)
-   dantman Daniel Friesen Copyright (C) 2010 XXX TODO License or CLA
-   fschaefer Florian Schäfer Copyright (C) 2010 MIT License
-   Gozala Irakli Gozalishvili Copyright (C) 2010 MIT License
-   kitcambridge Kit Cambridge Copyright (C) 2011 MIT License
-   kossnocorp Sasha Koss XXX TODO License or CLA
-   bryanforbes Bryan Forbes XXX TODO License or CLA
-   killdream Quildreen Motta Copyright (C) 2011 MIT Licence
-   michaelficarra Michael Ficarra Copyright (C) 2011 3-clause BSD
    License
-   sharkbrainguy Gerard Paapu Copyright (C) 2011 MIT License
-   bbqsrc Brendan Molloy (C) 2011 Creative Commons Zero (public domain)
-   iwyg XXX TODO License or CLA
-   DomenicDenicola Domenic Denicola Copyright (C) 2011 MIT License
-   xavierm02 Montillet Xavier Copyright (C) 2011 MIT License
-   Raynos Jake Verbaten Copyright (C) 2011 MIT Licence
-   samsonjs Sami Samhuri Copyright (C) 2010 MIT License
-   rwldrn Rick Waldron Copyright (C) 2011 MIT License
-   lexer Alexey Zakharov XXX TODO License or CLA
-   280 North Inc. (Now Motorola LLC, a subsidiary of Google Inc.)
    Copyright (C) 2009 MIT License
-   Steven Levithan Copyright (C) 2012 MIT License
