<template>
  <div>
    <svg-icon icon-class="question" @click="goto"/>
  </div>
</template>

<script>
export default {
  name: '文档',
  data() {
    return {
      url: 'https://gitee.com/zhunian/smart-pay-plus'
    }
  },
  methods: {
    goto() {
      window.open(this.url)
    }
  }
}
</script>
