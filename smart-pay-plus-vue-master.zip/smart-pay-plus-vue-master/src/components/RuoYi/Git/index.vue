<template>
  <div>
    <svg-icon icon-class="github" @click="goto"/>
  </div>
</template>

<script>
export default {
  name: '源码',
  data() {
    return {
      url: 'https://gitee.com/zhunian/smart-pay-plus'
    }
  },
  methods: {
    goto() {
      window.open(this.url)
    }
  }
}
</script>
